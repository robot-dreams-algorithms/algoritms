import L02.common.TestRunner;
import L02.tasks.*;

public class Main {
    public static void main(String[] args) {
        TestRunner.run(
                new T01(),
                new T02(),
                new T03(),
                new T04(),
                new T05()
        );
    }
}
