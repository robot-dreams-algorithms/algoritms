package L02.common;

public interface TestRunnable {
    boolean isReady();
    void runTest();
}
